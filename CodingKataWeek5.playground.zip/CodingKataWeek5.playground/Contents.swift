//: Playground - noun: a place where people can play

import UIKit



// #1
func divides(a:Int, b:Int) -> Bool
{
    if a % b == 0
    {
        return true
    }
    else
    {
        return false
    }
}
divides(a: 32, b: 16)

func countDivisors()
{
    
}












// #3
func reverse(arrayOfNumbers: [Int]) -> [Int]
{
    var reversedNumbers = [Int]()
    reversedNumbers = arrayOfNumbers.reversed()
    return reversedNumbers
}
reverse(arrayOfNumbers: [47, 16, 99, 1001, 6])








// #4
func timeDifference(firstHour: Int, firstMinute: Int, secondHour: Int, secondMinute: Int) -> Int
{
    let firstTime = (firstHour * 60) + firstMinute
    let secondTime = (secondHour * 60) + secondMinute
    return secondTime - firstTime
}

timeDifference(firstHour: 1, firstMinute: 30, secondHour: 9, secondMinute: 00)
//AM/PM would be an issue


