//: Playground - noun: a place where people can play

import UIKit

var steps = 0
var n = 16

func calculate(n:Int)
{
    var newNumber = Int()
    if n == 1
    {
        newNumber == n
    }
    else if n % 2 == 0
    {
        newNumber = n / 2
    }
    else
    {
        newNumber = (n * 3) + 1
    }
    steps = steps + 1
    print("Step\(steps) -> \(newNumber)")
    //checkIfFinished(newNumber)
    
}

func checkIfFinished(newNumber: Int)
{
    //if newNumber == 1
    
    
}



///^^^my crack at it.



//************

///actual answer below!!!!!!!!!!!


var sequence = [Int]()

//: The `collatz(start:Int, initial:Bool) -> [Int]` function takes an integer and will perform the following:
//:- if the integer (`n`) is 1, it will return an `[Int]` array.
//:- if the integer (`n`) is even, it will divide `n` by 2, append `n` to `[Int]`, and run the function again with `n`.
//:- if the integer (`n`) is odd, it will perform multiply `n` by 3 and add 1, add `n` to `[Int]`, and run the function again with `n`.
//: - note: If `initial` == `true`, the `start` variable is added to `[Int]`.
func collatz(start:Int, initial:Bool = true) -> [Int] {
    var n = start
    if initial == true {
        sequence.append(start)
    }
    
    if n == 1 {
        return sequence
    }
        
    else if n % 2 == 0 {
        n /= 2
        sequence.append(n)
    }
        
    else {
        n = (3 * n) + 1
        sequence.append(n)
    }
    
    return collatz(start: n, initial: false)
}

/*:
 - example: The basic use case for the `collatz` function.\
 \
 The array in this example contains all values for the sequence starting at n = 27. var x = n is used to show the graph.
 */
for n in collatz(start: 27, initial: true) {
    var x = n
}
